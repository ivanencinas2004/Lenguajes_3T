var result = document.getElementById("result");
var clear = document.getElementById("clear");
var square = document.getElementById("square");
var sqrt = document.getElementById("sqrt");
var percent = document.getElementById("percent");
var resultValue = "";
var operand1 = "";
var operand2 = "";
var operator = "";

function addNumber(num) {
  if (resultValue.length < 12) {
    resultValue += num;
    result.innerHTML = resultValue;
  }
}

function addDecimal() {
  if (resultValue.indexOf(".") == -1) {
    if (resultValue.length == 0) {
      resultValue += "0.";
    } else {
      resultValue += ".";
    }
    result.innerHTML = resultValue;
  }
}

function addOperator(op) {
  operator = op;
  operand1 = resultValue;
  resultValue = "";
}

function clearResult() {
  resultValue = "";
  operand1 = "";
  operand2 = "";
  operator = "";
  result.innerHTML = "0";
}

function calculate() {
  operand2 = resultValue;
  resultValue = "";
  var resultNum;
  switch(operator) {
    case "+":
      resultNum = parseFloat(operand1) + parseFloat(operand2);
      break;
    case "-":
      resultNum = parseFloat(operand1) - parseFloat(operand2);
      break;
    case "*":
      resultNum = parseFloat(operand1) * parseFloat(operand2);
      break;
    case "/":
      resultNum = parseFloat(operand1) / parseFloat(operand2);
      break;
    case "sqrt":
      resultNum = Math.sqrt(parseFloat(operand1));
      break;
    case "percent":
      resultNum = parseFloat(operand1) / 100;
      break;
    case "square":
      resultNum = parseFloat(operand1) * parseFloat(operand1);
      break;
    default:
      resultNum = parseFloat(resultValue);
  }
  result.innerHTML = resultNum.toString().substr(0, 12);
  operand1 = resultNum.toString();
  operand2 = "";
  operator = "";
  resultValue = "";
}

clear.addEventListener("click", function() {
  clearResult();
});

square.addEventListener("click", function() {
  addOperator("square");
  calculate();
});

sqrt.addEventListener("click", function() {
  addOperator("sqrt");
  calculate();
});

percent.addEventListener("click", function() {
  addOperator("percent");
  calculate();
});

document.getElementById("one").addEventListener("click", function() {
  addNumber("1");
});

document.getElementById("two").addEventListener("click", function() {
  addNumber("2");
});

document.getElementById("three").addEventListener("click", function() {
  addNumber("3");
});

document.getElementById("four").addEventListener("click", function() {
  addNumber("4");
});

document.getElementById("five").addEventListener("click", function() {
  addNumber("5");
});

document.getElementById("six").addEventListener("click", function() {
  addNumber("6");
});

document.getElementById("seven").addEventListener("click", function() {
  addNumber("7");
});

document.getElementById("eight").addEventListener("click", function() {
  addNumber("8");
});

document.getElementById("nine").addEventListener("click", function() {
  addNumber("9");
});

document.getElementById("zero").addEventListener("click", function() {
  addNumber("0");
});

document.getElementById("decimal").addEventListener("click", function() {
  addDecimal();
});

document.getElementById("add").addEventListener("click", function() {
  addOperator("+");
});

document.getElementById("subtract").addEventListener("click", function() {
  addOperator("-");
});

document.getElementById("multiply").addEventListener("click", function() {
  addOperator("*");
});

document.getElementById("divide").addEventListener("click", function() {
  addOperator("/");
});

document.getElementById("equals").addEventListener("click", function() {
  calculate();
});
